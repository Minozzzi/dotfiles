# Feature atual

> Única note operacional da feature em execução. Atualizar após mudanças de escopo, status, decisão, bloqueio, handoff, branch/MR ou evidência. Após concluir e reportar a feature, limpar esta note para conter somente `# Feature atual`.

## Identificação
| Campo | Valor |
|---|---|
| Workspace | `consorcio-create-counter-sales-function` |
| Workdir | `/Users/guilhermeminozzi/projects/consorcio-create-counter-sales-function` |
| Feature | A definir |
| Task | A definir |
| Status | Inicial |
| Última atualização | 2026-08-19 |

## Objetivo
(Aguardando nova tarefa)

## Escopo corrente
(Vazio)

## Estado operacional
- Decisões confirmadas: nenhuma registrada.
- Bloqueios: nenhum registrado.
- Handoff atual: não definido.
- Branch/MR: não registrados.
- Evidências: ainda não registradas.

## Próxima atualização obrigatória
Confirmar o status real da task e registrar responsável, branch/MR, decisões, verificações e próximo handoff quando a execução for iniciada.