# release-flow-rules

## Branches e Ambiente
- **Origem da branch:** A branch de feature/fix **sempre deve vir de `main`**.
- Padrão de nomeação: `<tipo>/<até-três-palavras-em-inglês>` (ex: `fix/min_filters`).
- Não inclua artefatos locais, credenciais ou diretórios de ferramentas no commit.

## Merge Requests
- Você deve abrir **dois Merge Requests** (MRs) para a mesma branch recém-criada:
  1. Um MR apontando para **`dev`** (Target: `dev`).
  2. Um MR apontando para **`main`** (Target: `main`).
- **Dependência:** O MR direcionado a `main` **deve ter uma dependência** para só ser mergeado após a aprovação e merge do MR da `dev`. (Isso garante que o código passe por DEV antes de ir para PRD).
- Antes de criar MRs, obtenha do usuário o reviewer; não invente nem reutilize um reviewer antigo.
- Leia o template do repositório e preserve a formatação Markdown.
- Verifique source branch, target branch, estado, reviewer, labels e dependências depois da criação.

## Atualização da tarefa
Publique somente os links confirmados, no formato:

#### DEV
<link_mr_dev>

#### PRD (Main)
<link_mr_prd>

Se a ferramenta disponível não permitir comentar na tarefa, informe a limitação e entregue o texto exato ao solicitante; não afirme que publicou.