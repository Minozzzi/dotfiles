# Backlog

> Ideias futuras priorizadas. Mover para `current-feature` ao iniciar.

## 🔥 Próximas
- Adicionar Rate Limiting (IP-based, ex: 10 req/min) no endpoint público POST /api/crm-lead para evitar spam.
- Validar se o `TenantId` existe de fato no banco de dados durante a execução do `CreateCrmLeadCommandHandler`.

## 💡 Ideias
- Mapear o campo `Origin` do CRM Lead para um Enum ou Whitelist no backend, evitando inserção de valores de origem arbitrários.

## 🧊 Icebox
_Vazio — ideias de longo prazo ou baixa prioridade._