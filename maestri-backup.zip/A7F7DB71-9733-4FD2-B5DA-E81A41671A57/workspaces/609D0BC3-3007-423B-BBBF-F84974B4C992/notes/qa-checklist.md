# qa-checklist

## Princípios
- Teste o contrato observável alterado (endpoint, comando ou entidade) e reproduza o comportamento real; não valide por inspeção textual nem por suposição.
- Nunca altere código-fonte de regras de negócio apenas para fazer um teste de infraestrutura passar de forma frágil.
- Não exponha credenciais, chaves de API, secrets ou tokens reais nas evidências.

## Verificação técnica
- Garanta a compilação limpa do projeto com `dotnet build`.
- Execute o teste unitário/integração focado que cobre a mudança de domínio ou handler (`dotnet test <CaminhoDoProjeto>`).
- Para mudanças permanentes, rode a suíte toda (`dotnet test`) para garantir que nenhuma regressão foi introduzida.
- Valide se o DDD foi mantido: sem lógicas de negócio no Application/Controller e integridade das Entities.
- Verifique a formatação com `dotnet format`.
- Registre comando, resultado e falhas reais sem ocultar warnings ou exceções relevantes.

## Verificação de Endpoint / API
- Inicie a API (`dotnet run --project Imowiz.Erp.Api`) e faça uma requisição real contra o fluxo no Swagger (`http://localhost:8080/swagger`) ou usando ferramentas como curl.
- Valide status HTTP (200, 201, 400 para erros de domínio, 401/403 para autenticação).
- Inspecione console e requests: confira payloads, JWT token e headers de tenant sem registrar segredos.
- Para fluxos de persistência, valide se a Migration foi criada/executada e se a mudança refletiu no banco (SQL ou MongoDB).

## Relatório
- Status: APROVADO ou REPROVADO.
- Cenários e comandos executados.
- Evidências observadas (códigos HTTP, body de resposta, output de testes).
- Passos de reprodução e impacto para cada defeito.