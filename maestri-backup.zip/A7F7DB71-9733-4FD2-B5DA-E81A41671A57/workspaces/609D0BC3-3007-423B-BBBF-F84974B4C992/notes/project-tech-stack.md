# project-tech-stack

## Stack verificada
- .NET 8.0 SDK (C#), ASP.NET Core Web API.
- Clean Architecture / Onion Architecture com princípios de Domain Driven Design (DDD) e Value Objects.
- CQRS utilizando MediatR para Commands, Command Handlers e Queries.
- Entity Framework Core para persistência relacional (SQL Server/PostgreSQL) e Dapper para consultas de alta performance.
- MongoDB para armazenamento flexível de documentos.
- Autenticação via JWT; Swagger/OpenAPI para documentação.
- Logging estruturado via Serilog e rastreamento de erros via Sentry.

## Estrutura relevante
- `Imowiz.Erp.Domain/`: Entidades centrais, Objetos de Valor (imutáveis) e Regras de Negócio puros.
- `Imowiz.Erp.App/`: Serviços de aplicação e orquestração.
- `Imowiz.Erp.Commands/` e `Imowiz.Erp.Queries/`: Definição dos contratos do CQRS (simples DTOs/records).
- `Imowiz.Erp.Handlers/`: Orquestração de comandos e consultas executando a lógica através do domínio.
- `Imowiz.Erp.Infra/`: Repositórios, acesso a dados, DbContexts e integrações externas (EF Core, Mongo, AWS S3).
- `Imowiz.Erp.Api/`: Controllers finos, injetando Mediator e sem regras de negócio.
- Siga estritamente as diretrizes do copilot-instructions.md: sem lógicas fora do Domain, use Exceptions de domínio, controllers magros.

## API e multitenancy
- Arquitetura Multi-tenant: todas as operações devem preservar o isolamento e validação de tenant conforme contexto da requisição.
- Autenticação e claims devem ser respeitadas.

## Verificação pré-entrega
- Compilação: `dotnet build` para assegurar que não há quebras.
- Testes: executar testes unitários (priorizar Domínio e Handlers) usando `dotnet test`. Execute o teste específico do fluxo alterado antes de rodar a suíte completa.
- Estilo: `dotnet format` para formatação do código.
- Migrations: caso o EF Core model seja alterado, crie a migration (`dotnet ef migrations add <Nome> --project Imowiz.Erp.Infra --startup-project Imowiz.Erp.Api`) e valide (`dotnet ef database update`).