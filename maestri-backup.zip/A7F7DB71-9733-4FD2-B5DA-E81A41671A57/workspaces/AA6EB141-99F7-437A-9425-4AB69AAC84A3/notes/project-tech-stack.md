# project-tech-stack

## Stack verificada
- .NET (C#) projetado com arquitetura limpa / DDD.
- API Web (Controllers, Swagger).
- DynamoDB configurado como banco de dados principal.
- Testes divididos em Unitários e de Integração na pasta `tests/`.

## Estrutura relevante
- `src/ConsorcioCmsDomain.Api/`: Camada de apresentação, Controllers, Middlewares, Program.cs.
- `src/ConsorcioCmsDomain.App/`: Serviços de aplicação, orquestração de casos de uso.
- `src/ConsorcioCmsDomain.Contracts/`: Contratos de dados (DTOs, Interfaces, Requests/Responses).
- `src/ConsorcioCmsDomain.CrossCutting/`: Injeção de dependência, configurações globais.
- `src/ConsorcioCmsDomain.Domain/`: Entidades de domínio, eventos de domínio, interfaces de repositórios.
- `src/ConsorcioCmsDomain.Infra/`: Repositórios, integrações externas.
- `tests/ConsorcioCmsDomain.Unit.Tests/`: Testes unitários.
- `tests/ConsorcioCmsDomain.Integration.Tests/`: Testes de integração.

## API e DDD
- Siga os princípios do Domain-Driven Design: Entidades, Objetos de Valor, Agregados, e Repositórios.
- Option Monad e Result Pattern devem ser usados para controle de fluxo e erros, evitando exceptions para fluxo de negócio.
- Single Responsibility para Services.
- Siga as configurações e padrões já existentes no repositório; não introduza uma segunda convenção.

## Verificação pré-entrega
- Compilação: `dotnet build` ou usar o `ConsorcioCmsDomain.sln`.
- Testes: `dotnet test`.
- Formatação: `dotnet format` se aplicável.
