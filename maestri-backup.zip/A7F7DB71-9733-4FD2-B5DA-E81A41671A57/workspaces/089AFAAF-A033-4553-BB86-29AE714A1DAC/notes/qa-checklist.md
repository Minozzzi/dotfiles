# qa-checklist

## Princípios
- Teste o contrato observável alterado e reproduza o comportamento real; não valide por inspeção textual nem por suposição.
- Nunca altere código-fonte, fixtures ou testes apenas para fazer a verificação passar.
- Não exponha credenciais, documentos ou tokens nas evidências.
- Como o projeto é uma API Serverless, foque em contratos de entrada/saída, validações e tratamento de erros.

## Verificação técnica
- Execute `npm run test` e assegure que todos os testes (incluindo os novos) passam.
- Execute `npm run check` para garantir aderência ao Lint e Prettier.
- Para CI/CD local, pode rodar `npm run test:ci` para checar o coverage se necessário.
- Valide se o build ocorre com sucesso: `npm run build` e `npm run build:swagger`.
- Registre comando, resultado e falhas reais sem ocultar warnings relevantes.

## Verificação funcional de API
- Valide os mappers de/para a API do Bradesco; garanta que os DTOs não permitem vazamento de dados inesperados.
- Teste respostas de sucesso e erro (HTTP status codes, payload de erro) nos serviços ou endpoints mockados.
- Se realizar teste com API real usando Postman, cURL ou script, inspecione a estrutura do payload, headers de autorização e performance.
- Não há interface visual (UI) para testar, portanto as evidências são logs de console, payloads JSON e status de execução dos testes de unidade.

## Relatório
- Status: APROVADO ou REPROVADO.
- Cenários de testes e comandos executados.
- Evidências observadas (JSON de payload, logs do Vitest).
- Passos de reprodução e impacto para cada defeito.