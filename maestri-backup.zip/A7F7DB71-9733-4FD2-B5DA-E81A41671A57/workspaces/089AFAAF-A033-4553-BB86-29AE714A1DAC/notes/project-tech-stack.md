# project-tech-stack

## Stack verificada
- AWS Lambda Function em Node.js 20 e TypeScript.
- API Gateway para roteamento (declarado via Terraform).
- Vitest para testes unitários e coverage.
- esbuild para empacotamento.
- Swagger para documentação de API (`swagger-jsdoc`).
- Middleware Middy (`@middy/core`).
- AWS SDK (Secrets Manager), Lambda Powertools (Tracer), e X-Ray SDK.
- Pacotes internos da Aarin (`@aarintech/consorcio-bra-client-lib`, `@aarintech/consorcio-utils-lib`).
- npm é o gerenciador do projeto.

## Estrutura relevante
- `src/app.ts`: Entrypoint para a função Lambda `APIGatewayProxyEvent`.
- `src/constants/`: Constantes utilizadas na aplicação.
- `src/dtos/`: Data transfer objects.
- `src/enums/`: Tipos de enumeração.
- `src/errors/`: Classes de erro customizadas.
- `src/lib/`: Funções cross-library com Result Pattern.
- `src/mappers/`: Mapeamento de respostas da API Bradesco para o formato de domínio Aarin.
- `src/services/`: Integração com APIs externas.
- `terraform/`: Infraestrutura as Code (IaC) - roteamento do API Gateway, etc.
- `__tests__/`: Testes unitários (mocks, fakes, services, setup).
- Uso de Layers: imports como `/opt/name-layer` com `@ts-ignore` (ex: em tempo de execução via `nodejs20`).

## API e Integrações
- Integrações de API utilizando contratos estritos; preservar mappers existentes.
- Rotas devem ser declaradas no `terraform/api_gateway.tf` usando `aws_api_gateway_resource`.

## Verificação pré-entrega
- Testes: Executar `npm run test` para validação local.
- Lint e Formatação: `npm run check` (valida ESLint e Prettier).
- Autofix de lint: `npm run autofix`.
- Build da Função: `npm run build`.
- Build do Swagger: `npm run build:swagger`.