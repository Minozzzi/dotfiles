# release-flow-rules

## Branches
- Crie a branch a partir de `main`.
- Use o prefixo adequado ao tipo de alteração (`feat`, `fix` ou `chore`).
- Siga o padrão: `<tipo>/<id-da-task>_<até-três-palavras-em-inglês>`.
- Não inclua artefatos locais, credenciais ou diretórios de ferramentas no commit.

## Merge Requests
- Antes de criar MRs, obtenha do usuário o reviewer; não invente nem reutilize um reviewer antigo.
- Leia o template do repositório e preserve a formatação Markdown com linhas em branco antes dos cabeçalhos.
- Target branch: **Sempre `main`**.
- Prefira GitLab MCP/API para metadados de MR; não crie commits vazios nem use push options para editar título/descrição.
- Verifique source branch, target branch, estado, reviewer e labels depois da criação.

## Atualização da tarefa
Publique somente o link confirmado do MR, no formato:

#### MR (main)
<link_mr>

Se a ferramenta disponível não permitir comentar na tarefa, informe a limitação e entregue o texto exato ao solicitante; não afirme que publicou.