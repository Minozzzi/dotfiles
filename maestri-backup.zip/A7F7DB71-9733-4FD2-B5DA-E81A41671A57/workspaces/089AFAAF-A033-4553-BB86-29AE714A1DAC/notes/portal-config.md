# portal-config

## Política
- Em projetos Serverless/Lambda, não há uma interface visual tradicional (Portal UI).
- O "Portal" refere-se à interface de documentação da API (Swagger) ou à interação com clientes HTTP (Postman/cURL/Insomnia).
- Inicie a verificação de API garantindo que o build do Swagger roda corretamente (`npm run build:swagger`).

## Fluxo
1. Verifique se o JSON do Swagger está sendo gerado corretamente ou se há mocks configurados em `__tests__/mocks`.
2. Para validação de contratos locais, rode os testes unitários (`npm run test`) ou use scripts em Node para simular a chamada ao handler `app.ts`.
3. Se um ambiente de homologação da Lambda (AWS) estiver disponível e for necessário acesso real, colete a URL da API Gateway.
4. Realize a chamada ao endpoint passando os headers, parâmetros de query/path requeridos no Swagger.
5. Capture as respostas JSON de evidência (sucesso/erro), removendo ou mascarando chaves sensíveis (como secrets do AWS Secrets Manager ou tokens).