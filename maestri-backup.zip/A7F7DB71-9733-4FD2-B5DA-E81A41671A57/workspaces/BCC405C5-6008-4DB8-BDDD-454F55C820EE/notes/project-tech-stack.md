# project-tech-stack

## Stack verificada
- .NET (C#) projetado com arquitetura limpa / DDD.
- DynamoDB como banco de dados NoSQL (via `docker-compose-dynamodb.yml`).
- API Web (Controllers, Swagger).
- Testes unitários na pasta `tests/`.

## Estrutura relevante
- `src/ConsorcioProposals.Api/`: Camada de apresentação, Controllers, Middlewares, Program.cs.
- `src/ConsorcioProposals.App/`: Serviços de aplicação, orquestração de casos de uso.
- `src/ConsorcioProposals.Contracts/`: Contratos de dados (DTOs, Interfaces, Requests/Responses).
- `src/ConsorcioProposals.CrossCutting/`: Injeção de dependência, configurações globais.
- `src/ConsorcioProposals.Infra/`: Repositórios, acesso ao DynamoDB, integrações externas.
- `tests/`: Projetos de testes da aplicação.
- `bruno-collection/`: Coleção de requests HTTP para testes manuais via Bruno.

## API e DDD
- Siga os princípios do Domain-Driven Design: Entidades, Objetos de Valor, Agregados, e Repositórios.
- Option Monad e Result Pattern devem ser usados para controle de fluxo e erros, evitando exceptions para fluxo de negócio.
- Single Responsibility para Services.
- Siga as configurações e padrões já existentes no repositório; não introduza uma segunda convenção.

## Verificação pré-entrega
- Compilação: `dotnet build`.
- Testes: `dotnet test`.
- Formatação: `dotnet format` se aplicável.
- Funcional: Testar endpoints localmente (DynamoDB no docker + dotnet run/run via API).