# project-tech-stack

## Stack verificada
- Next.js 15.5 (App Router), React 19 e TypeScript com verificação por `tsc --noEmit`.
- Redux Toolkit e RTK Query para estado e acesso a dados.
- Material UI v6, Emotion, `@mui/icons-material` e `@aarintech/icons`.
- React Hook Form com Zod para formulários e validação.
- Amplitude e Datadog RUM para analytics/observabilidade.
- Testes com Jest e React Testing Library.
- pnpm é o gerenciador do projeto (v10).

## Estrutura relevante
- `src/app/`: rotas e layouts do App Router.
- `src/modules/<domínio>/`: componentes, hooks, helpers e tipos das features.
- `src/config/data/services/`: endpoints RTK Query e tipos de API.
- `src/config/stores/`: configuração e reducers do Redux Toolkit.
- `src/components/`: componentes compartilhados.
- Siga as configurações e padrões já existentes no repositório; não introduza uma segunda convenção.

## API e multitenancy
- Preserve o fluxo de headers e autenticação definido pelo baseQuery e pelos endpoints existentes.
- Mudanças de autenticação devem ficar no menor escopo correto e preservar os contratos de resposta existentes.

## Verificação pré-entrega
- Verificação de tipos: `pnpm type-check`.
- Testes: primeiro o teste focado no contrato alterado; depois `pnpm test` quando a mudança for permanente.
- Lint: `pnpm lint`; use `pnpm lint:fix` apenas quando a alteração automática for intencional e o diff for revisado.
- Código morto: `pnpm find-deadCode` (usa Knip).
- Mudança de UI: executar o app e validar o fluxo real no browser.