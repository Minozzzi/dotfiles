# Feature atual

> Única note operacional da feature em execução. Atualizar após mudanças de escopo, status, decisão, bloqueio, handoff, branch/MR ou evidência. Após concluir e reportar a feature, limpar esta note para conter somente `# Feature atual`.

## Identificação
| Campo | Valor |
|---|---|
| Workspace | `sales-portal-frontend` |
| Workdir | `/Users/guilhermeminozzi/projects/sales-portal-frontend` |
| Feature | Exportar proposta com novas colunas de desconto |
| Task | [86ajw79tc](https://app.clickup.com/t/86ajw79tc) |
| Status | In Progress |
| Última atualização | 2026-08-12 |

## Objetivo
Incluir percentual e valor de desconto na proposta exportada e manter os detalhes e o resumo da oferta coerentes com os mesmos dados.

## Escopo corrente
- PDF de Exportar Proposta: adicionar `% de desc.` e `Valor desc.` em `src/modules/export-offer/index.tsx`.
- Detalhes da cota: exibir `percentageDiscount` e `discountValue` em `src/modules/offer-details/components/ProductQuota/index.tsx`.
- Resumo da oferta: avaliar total ou média de desconto em `src/modules/offer-details/helpers/calculateOfferDetails.ts`.

## Estado operacional
- Decisões confirmadas: nenhuma registrada.
- Bloqueios: nenhum registrado.
- Handoff atual: não definido.
- Branch/MR: `feat/dev_86ajw79tc_export_offer_discount` (MR não criado)
- Evidências: ainda não registradas.

## Próxima atualização obrigatória
Iniciar implementação, validando primeiro `ProductQuota`, depois `calculateOfferDetails` e por fim o PDF em `export-offer`. Atualizar evidências assim que a primeira tela estiver renderizando.