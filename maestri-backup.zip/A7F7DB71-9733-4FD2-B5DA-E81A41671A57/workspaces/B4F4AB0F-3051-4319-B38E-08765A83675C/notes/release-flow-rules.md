# release-flow-rules

## Branches e Incrementos
- A branch DEVE ser criada/puxada SEMPRE a partir da branch `main`.
- Padrão de nomenclatura: `<tipo>/<id-da-task>_<até-três-palavras-em-inglês>`.
- Ao alterar o chart, o Release Manager deve validar se o `version` no `Chart.yaml` foi adequadamente atualizado (bump), pois o CI subirá a nova versão ao Registry.

## Merge Requests
- Será aberto **apenas 1 Merge Request** para este repositório.
- Target branch: **SEMPRE `main`**.
- Antes de criar o MR, obtenha do usuário o reviewer; não invente nem reutilize um reviewer antigo.
- Leia o template do repositório (se existir) e preserve a formatação.
- Prefira usar o Aarin MCP ou automações do GitLab se disponíveis.
- Após o merge em `main`, a pipeline no `.gitlab-ci.yml` usará `helm package` e `helm cm-push` para publicar o Chart.

## Atualização da tarefa
Publique somente o link confirmado, no formato:

#### MR
<link_mr>

Se a ferramenta disponível não permitir comentar na tarefa, informe a limitação e entregue o texto exato ao solicitante.