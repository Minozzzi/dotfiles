# qa-checklist

## Princípios
- Validar se os templates do Helm renderizam corretamente o manifesto final do Kubernetes para cada ambiente (dev, sandbox, main).
- Nenhuma secret real (senhas, tokens) deve ser hardcoded nos arquivos de values. Use as abordagens padrão (injeção no pipeline ou via configmaps/external-secrets).
- O foco da QA aqui é a integridade dos artefatos de infra/deploy (Helm Charts), não testes de unidade em C#.

## Verificação técnica
- Execute lint para verificar se há problemas estruturais no Chart:
  `helm lint src/consorcio-simulations-api/`
- Verifique a renderização (template) em todos os ambientes usando o values base e os overrides:
  - DEV: `helm template release-test src/consorcio-simulations-api/ -f src/consorcio-simulations-api/values-dev.yaml`
  - SANDBOX: `helm template release-test src/consorcio-simulations-api/ -f src/consorcio-simulations-api/values-sandbox.yaml`
  - MAIN (PRD): `helm template release-test src/consorcio-simulations-api/ -f src/consorcio-simulations-api/values-main.yaml`
- Confirme manualmente na saída (yaml) se os valores alterados/esperados (imagem, replicas, environments, ports) estão sendo gerados de forma correta.

## Verificação funcional da API (via Helm)
- Como não há `.NET` local neste repo, o "teste de API" é garantir que o Helm levanta os Pods corretamente, via dry-run, sem erros de template.

## Relatório
- Status: APROVADO ou REPROVADO.
- Comandos `helm lint` e `helm template` executados com sucesso (sem falhas de template render).
- Evidências: saída do lint ou a confirmação das configurações injetadas corretas no dry run.