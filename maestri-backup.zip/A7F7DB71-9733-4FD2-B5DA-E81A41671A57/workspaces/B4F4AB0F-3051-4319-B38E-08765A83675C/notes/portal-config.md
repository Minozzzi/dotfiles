# portal-config

## Política
- Neste workspace gerenciamos exclusivamente os artefatos de infraestrutura/deploy (Helm Chart), logo não há uma aplicação `.NET` sendo compilada com `dotnet build` ou executada via `dotnet run`.
- O "portal" de testes para os artefatos Helm é geralmente o comando `helm template` (para validações estáticas) ou a simulação em um cluster Kubernetes de desenvolvimento (local via minikube/kind ou o cluster da empresa).

## Fluxo (Validação de Deploy no Kubernetes)
1. Para validar alterações de maneira estática, utilize puramente o CLI do Helm.
2. Certifique-se de usar a dependência base (pode ser necessário atualizar: `helm dependency update src/consorcio-simulations-api/`).
3. Para validar estaticamente (sem acesso a cluster real):
   `helm template mock-release src/consorcio-simulations-api -f src/consorcio-simulations-api/values-dev.yaml`
4. Se o usuário fornecer acesso a um cluster e solicitar validação real (dry-run):
   `helm install --dry-run mock-release src/consorcio-simulations-api -f src/consorcio-simulations-api/values-dev.yaml`
5. Confirme que todos os Resources (Deployment, Service, Ingress/Route, ConfigMap) saem configurados perfeitamente como esperado.

Consulte o `qa-checklist` para o passo-a-passo detalhado.