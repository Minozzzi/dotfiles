# project-tech-stack

## Stack verificada
- Helm (Kubernetes Package Manager).
- CI/CD via GitLab CI (`.gitlab-ci.yml`) que publica o chart Helm no Registry do GitLab.
- O chart depende de `helm-aarin-base` (Aarin Helm Chart Base).

## Estrutura relevante
- `src/consorcio-simulations-api/`: Diretório do Chart Helm da API.
  - `Chart.yaml`: Define versão do chart e a dependência com `helm-aarin-base`.
  - `values-dev.yaml`: Configurações de deployment para ambiente DEV.
  - `values-sandbox.yaml`: Configurações de deployment para ambiente SANDBOX.
  - `values-main.yaml`: Configurações de deployment para ambiente de PRODUÇÃO (main).
  - `values-template.yaml`: Template base dos valores.
- `.gitlab-ci.yml`: Pipeline para testar e publicar (`helm lint`, `helm package` e `helm cm-push`).
- `README.md` e `CHANGELOG`: Documentação e histórico do pacote Helm.

## Padrões
- Configurações Kubernetes (resources, vars, secrets) devem ser parametrizadas puramente via `values-*.yaml`.
- Seguir as definições aceitas pelo `helm-aarin-base`. Não reescrever templates que a base já provê; apenas configurar os resources no arquivo de values.
- Mantenha a versão do chart em sincronia.

## Verificação pré-entrega
- Lint do Chart: `helm lint src/consorcio-simulations-api/`
- Renderização de templates (Dry Run para testar valores): `helm template api-test src/consorcio-simulations-api/ -f src/consorcio-simulations-api/values-dev.yaml`