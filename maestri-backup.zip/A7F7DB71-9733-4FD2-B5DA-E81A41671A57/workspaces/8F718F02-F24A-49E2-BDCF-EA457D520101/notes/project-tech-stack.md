# project-tech-stack

## Stack verificada (IaC)
- Ferramenta: **Terraform** (`>= 1.8.5`)
- Provider: AWS (`>= 5`)
- CI/CD: GitLab CI (template: `terraform-lambda-pipeline-v2.yaml`)
- Automação local: `pre-commit` hooks

## Estrutura e Recursos
- Todo o código Terraform está provisionado no diretório `lambda/`.
- Módulo Core: Utiliza o `gitlab.com/aarintechfin/terraform-module-lambda/aws` (versão `2.1.0`).
- Objetivo: Provisionar a Lambda Function `get-sales-report-by-vendor` com suas devidas roles e policies.
- Estado: Armazenado remotamente num bucket S3 (`terraform-872515293433-tfstate`).

## Verificação e Qualidade (Pre-commit)
As ferramentas seguintes estão configuradas e exigidas:
- `terraform fmt`: Formatação.
- `terraform validate`: Validação sintática.
- `tflint`: Linter do Terraform.
- `checkov`: Verificação de segurança de IaC.

## Fluxo de Deploy
Definido via `variables` no `.gitlab-ci.yml`:
- Development: `us-east-2`
- Sandbox: `us-east-1`
- Production: `sa-east-1`