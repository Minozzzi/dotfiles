# portal-config

## Política (Ambiente IaC)
- Não existe interface visual tradicional, UI, Swagger ou aplicação rodando diretamente neste projeto.
- Este projeto foca apenas na **criação de infraestrutura** (AWS Lambda) via Terraform.
- O Portal para este projeto concentra-se em:
  1. Console da AWS (para checar a Lambda).
  2. Interface do GitLab CI (para checar os logs de Plan e Apply do Terraform).

## Fluxo de Checagem
1. Se precisar confirmar o funcionamento do artefato Terraform criado, verifique os Jobs no GitLab MR.
2. Acessos à AWS geralmente requerem assumir roles pertinentes da Aarin; como agente, dependa estritamente das saídas de validação estática local (`pre-commit`) ou do pipeline CI.
3. Não tente iniciar aplicações locais ou realizar requisições HTTP curl, pois o código fonte da Lambda não é compilado nem servido a partir deste diretório (apenas referenciado nos buckets AWS no TF).