# qa-checklist

## Princípios
- Trata-se de um repositório exclusivamente de infraestrutura como código (Terraform).
- Valide as mudanças com comandos estáticos locais antes do commit.
- O sucesso da CI/CD no GitLab é obrigatório.

## Verificação técnica (Local)
Para aprovar a mudança localmente, garanta que os seguintes passos foram executados sem erros:
1. `cd lambda` (pois o código TF fica nesta pasta).
2. Execute a inicialização local (sem backend remoto para não travar):
   `terraform init -backend=false`
3. Formatação de código:
   `terraform fmt -recursive`
4. Validação sintática:
   `terraform validate`
5. Para rodar todo o checklist padronizado de uma vez (o mais recomendado):
   `pre-commit run --all-files`

## Verificação em Pipeline
- O resultado efetivo só pode ser confirmado nos logs do GitLab CI (`Validate`, `Plan` e `Apply`).
- Um Terraform Plan limpo (somente o que deve ser modificado) nas stages correspondentes garante sucesso pré-merge.

## Relatório
- Status: APROVADO ou REPROVADO.
- Comando executado (ex: `pre-commit run --all-files`).
- Saída do validate/tflint/checkov (evidências textuais do console).
- Impacto infraestrutural (quantos recursos to be added, changed, destroyed, caso aplicável).