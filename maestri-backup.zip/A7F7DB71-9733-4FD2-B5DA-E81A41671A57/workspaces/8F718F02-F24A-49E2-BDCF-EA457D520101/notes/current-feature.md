# Feature atual

> Única note operacional da feature em execução. Atualizar após mudanças de escopo, status, decisão, bloqueio, handoff, branch/MR ou evidência. Após concluir e reportar a feature, limpar esta note para conter somente `# Feature atual`.

## Identificação
| Campo | Valor |
|---|---|
| Workspace | `consorcio-get-sales-report-by-vendor-tf` |
| Workdir | `/Users/guilhermeminozzi/projects/consorcio-get-sales-report-by-vendor-tf` |
| Feature | A definir |
| Task | A definir |
| Status | Inicial (Aguardando instrução) |
| Última atualização | 2026-08-19 |

## Objetivo
(Aguardando nova tarefa)

## Escopo corrente
- O projeto no momento possui apenas a branch `main`.
- Código Terraform base já existe no diretório `lambda/`.

## Estado operacional
- Decisões confirmadas: Nenhuma.
- Bloqueios: Nenhum.
- Handoff atual: Não definido.
- Branch/MR: Não registrados.
- Evidências: Nenhuma.

## Próxima atualização obrigatória
Confirmar o status real da task e registrar responsável, branch/MR, decisões, verificações e próximo handoff quando a execução for iniciada.