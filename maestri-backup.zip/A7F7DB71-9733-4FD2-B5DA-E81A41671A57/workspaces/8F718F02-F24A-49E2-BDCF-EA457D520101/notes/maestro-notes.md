# Workspace notes index

> Entrada principal deste workspace. `current-feature` é a única note da feature em execução; as demais notes são contexto permanente ou restrito.

## Contexto ativo
| Item | Valor |
|---|---|
| Workspace | `consorcio-get-sales-report-by-vendor-tf` |
| Workdir | `/Users/guilhermeminozzi/projects/consorcio-get-sales-report-by-vendor-tf` |
| Branch default | `main` (única branch atual) |
| Feature atual | `current-feature` |
| Governança | `maestri-governance` |

## Fluxo essencial do time
`Task Creator → Spec → Planner → Coder → Tester → Release Manager`

Apoios: `Spec ↔ Journey → Tester`, `Spec ↔ Architect → Planner` e `Coder HotFixer → Tester`. O Maestro permanece conectado a todos e integra exceções.

## Contexto permanente
| Note | Conectada a | Finalidade |
|---|---|---|
| `project-tech-stack` | Architect, Planner, Coder, HotFixer e Tester | Stack IaC, módulos e comandos Terraform |
| `qa-checklist` | Journey, Coder, HotFixer e Tester | Validação Terraform (pre-commit, validate, tflint) |
| `portal-config` | Journey e Tester | Acesso AWS e Pipelines CI/CD |
| `release-flow-rules` | Release Manager | Branches, MRs e pipelines de deploy |
| `maestri-governance` | Encadeada a este índice | Regras do workspace |

## Contexto restrito
- `restricted-login-credential`: conectada somente ao Maestro. Compartilhar apenas durante autenticação real necessária.

## Lifecycle da feature
1. Não crie notes individuais por feature.
2. Atualize `current-feature` a cada mudança de objetivo, escopo, status, decisão, bloqueio, handoff, branch/MR ou evidência.
3. Após concluir e reportar a feature, deixe a note contendo somente `# Feature atual`.
4. Ao trocar de prioridade antes da conclusão, substitua o conteúdo somente após confirmar com o usuário.