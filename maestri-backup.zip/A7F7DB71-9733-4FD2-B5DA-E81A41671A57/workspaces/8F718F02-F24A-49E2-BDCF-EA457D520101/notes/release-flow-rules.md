# release-flow-rules

## Branches
- Crie a branch sempre a partir de `main`.
- Use o prefixo adequado ao tipo de alteração (`feat`, `fix` ou `chore`).
- Siga o padrão: `<tipo>/<id-da-task>_<até-três-palavras-em-inglês>`.
- Lembre-se: O código de infraestrutura está sujeito aos hooks do `pre-commit`. Garanta que eles passam antes de efetivar o push.

## Merge Requests
- Antes de criar MRs, obtenha do usuário o reviewer.
- Target branch: **Sempre `main`**.
- Leia o template do repositório (se aplicável) e preserve a formatação Markdown.
- O MR irá disparar a pipeline definida em `terraform-lambda-pipeline-v2.yaml` (Prepare -> Validate -> Plan...).
- Verifique os stages do GitLab CI após a submissão para certificar-se que o Terraform Plan foi executado adequadamente para o ambiente desejado.

## Atualização da tarefa
Publique somente o link confirmado do MR, no formato:

#### MR (main)
<link_mr>

Se a ferramenta disponível não permitir comentar na tarefa, informe a limitação e entregue o texto exato ao solicitante; não afirme que publicou.