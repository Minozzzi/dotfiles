# portal-config

## Política
- Validações reais de API devem ser feitas contra uma instância local em execução (usando `dotnet run` ou `docker-compose up` para dependências como DynamoDB).
- Utilize Swagger UI ou curl para interagir com a API.
- Dê ao ambiente de teste um nome descritivo e compartilhe a URL correta com os agentes.

## Fluxo
1. Suba as dependências (ex: `docker-compose up -d` se aplicável).
2. Confirme que a API está rodando (`dotnet run` no projeto da Api) e respondendo no healthcheck.
3. Utilize curl ou Swagger UI para realizar requests, validando contratos, status codes e payloads.
4. Valide logs no console (ex: `api.log` ou console do dotnet) conforme `qa-checklist`.
5. Capture evidências sem expor credenciais de produção.
6. Encerre a execução local ao concluir.

Consulte `maestri portal --help` antes de usar flags ou comandos que não tenham sido verificados nesta sessão.