# project-tech-stack

## Stack verificada
- .NET (C#) projetado com arquitetura limpa / DDD.
- API Web (Controllers, Swagger).
- Testes divididos em Unitários e de Integração na pasta `tests/`.

## Estrutura relevante
- `src/ConsorcioCmsApi.Api/`: Camada de apresentação, Controllers, Middlewares, Program.cs.
- `src/ConsorcioCmsApi.App/`: Serviços de aplicação, orquestração de casos de uso.
- `src/ConsorcioCmsApi.Contracts/`: Contratos de dados (DTOs, Interfaces, Requests/Responses).
- `src/ConsorcioCmsApi.CrossCutting/`: Injeção de dependência, configurações globais.
- `src/ConsorcioCmsApi.Infra/`: Repositórios, integrações externas.
- `tests/ConsorcioCmsApi.Unit.Tests/`: Testes unitários.
- `tests/ConsorcioCmsApi.Integration.Tests/`: Testes de integração.

## API e DDD
- Siga os princípios do Domain-Driven Design: Entidades, Objetos de Valor, Agregados, e Repositórios.
- Option Monad e Result Pattern devem ser usados para controle de fluxo e erros, evitando exceptions para fluxo de negócio.
- Single Responsibility para Services.
- Siga as configurações e padrões já existentes no repositório; não introduza uma segunda convenção.

## Verificação pré-entrega
- Compilação: `dotnet build` ou usar o `ConsorcioCmsApi.sln`.
- Testes: `dotnet test`.
- Formatação: `dotnet format` se aplicável.