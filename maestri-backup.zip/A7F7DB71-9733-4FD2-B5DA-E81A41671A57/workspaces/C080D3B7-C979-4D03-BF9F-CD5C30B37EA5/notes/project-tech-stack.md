# project-tech-stack

## Stack verificada
- AWS Lambda Function em Node.js 24 e TypeScript.
- Vitest para testes unitários e coverage.
- esbuild para empacotamento.
- AWS SDK (Secrets Manager, S3, SES).
- nodemailer para envio de e-mails.
- Pacotes internos da Aarin (`@aarintech/consorcio-utils-lib`, `@aarintech/aarin-cache-lib`).
- npm é o gerenciador do projeto.

## Estrutura relevante
- `src/app.ts`: Entrypoint para a função Lambda que processa o evento `ProposalSignedEvent`.
- `src/constants/`: Constantes utilizadas na aplicação.
- `src/dtos/`: Data transfer objects (Requests/Events).
- `src/errors/`: Classes de erro customizadas.
- `src/services/`: Serviços de integração (S3, Secrets Manager, SMTP, Cache, PDF rendering).
- `__tests__/`: Testes unitários (mocks, fakes, services, setup).
- Uso de Layers: imports como `/opt/name-layer` com `@ts-ignore` (ex: em tempo de execução via `nodejs24`).

## Verificação pré-entrega
- Testes: Executar `npm run test` para validação local.
- Lint e Formatação: `npm run check` (valida ESLint e Prettier).
- Autofix de lint: `npm run autofix`.
- Build da Função: `npm run build`.