# portal-config

## Política
- Em projetos Serverless/Lambda orientados a eventos, não há uma interface visual tradicional (Portal UI) nem um endpoint HTTP síncrono (Swagger).
- O "Portal" refere-se à inspeção do payload de evento (ex: `ProposalSignedEvent`) e a verificação do output gerado (envio de e-mail).

## Fluxo
1. Verifique se os mocks de eventos estão configurados em `__tests__/mocks` para testes unitários.
2. Para validação do processamento, rode os testes unitários (`npm run test`) para simular a execução da Lambda `lambdaHandler`.
3. Certifique-se de que a formatação e geração dos templates de e-mail ocorrem de acordo com as especificações.
4. Capture os logs e validações do processamento como evidências de sucesso/erro.