# qa-checklist

## Princípios
- Teste o contrato observável alterado e reproduza o comportamento real; não valide por inspeção textual nem por suposição.
- Nunca altere código-fonte, fixtures ou testes apenas para fazer a verificação passar.
- Não exponha credenciais, documentos ou tokens nas evidências.
- Como o projeto é uma Lambda orientada a eventos (background worker), foque no fluxo de processamento, tratamento de dados (e.g., renderização de PDF, templates) e integrações externas (S3, SES, SMTP).

## Verificação técnica
- Execute `npm run test` e assegure que todos os testes (incluindo os novos) passam.
- Execute `npm run check` para garantir aderência ao Lint e Prettier.
- Para CI/CD local, pode rodar `npm run test:ci` para checar o coverage se necessário.
- Valide se o build ocorre com sucesso: `npm run build`.
- Registre comando, resultado e falhas reais sem ocultar warnings relevantes.

## Verificação funcional da Lambda
- Valide o processamento dos eventos esperados (como `ProposalSignedEvent`).
- Teste respostas de sucesso e erro (Result Pattern) da função `lambdaHandler`.
- Valide o envio correto de emails simulado através dos mocks do `nodemailer` ou SES em testes.
- As evidências são logs de console, payloads JSON gerados, anexos/PDFs (em base64 ou mock) e status de execução dos testes de unidade.

## Relatório
- Status: APROVADO ou REPROVADO.
- Cenários de testes e comandos executados.
- Evidências observadas (JSON de payload, logs do Vitest).
- Passos de reprodução e impacto para cada defeito.