# Feature atual

> Única note operacional da feature em execução. Atualizar após mudanças de escopo, status, decisão, bloqueio, handoff, branch/MR ou evidência. Após concluir e reportar a feature, limpar esta note para conter somente `# Feature atual`.

## Identificação
| Campo | Valor |
|---|---|
| Workspace | `consorcio-simulations-api` |
| Workdir | `/Users/guilhermeminozzi/projects/consorcio-simulations-api` |
| Feature | A definir |
| Task | A definir |
| Status | Pendente |
| Última atualização | 2026-08-12 |

## Objetivo
A definir.

## Escopo corrente
- A definir.

## Estado operacional
- Decisões confirmadas: nenhuma registrada.
- Bloqueios: nenhum registrado.
- Handoff atual: não definido.
- Branch/MR: não registrados.
- Evidências: ainda não registradas.

## Próxima atualização obrigatória
Confirmar o status real da task e registrar responsável, branch/MR, decisões, verificações e próximo handoff quando a execução for iniciada.