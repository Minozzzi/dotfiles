# Restricted: login credentials

> Conteúdo sensível. Manter conectada somente ao Maestro. Não copiar para código, logs, screenshots, PRs, tasks ou notes compartilhadas.
> A origem desta credencial não foi validada para imowiz-frontend durante a migração de contexto; não usar até confirmar o ambiente e a autorização com o usuário.

## Credencial de teste registrada
| Campo | Valor |
|---|---|
| email | `reinaldohasseln@gmail.com` |
| Senha | `Teste@123` |

## Uso
Compartilhar apenas com o agente que executar autenticação real e somente durante a validação necessária. Recolher o acesso ao concluir.