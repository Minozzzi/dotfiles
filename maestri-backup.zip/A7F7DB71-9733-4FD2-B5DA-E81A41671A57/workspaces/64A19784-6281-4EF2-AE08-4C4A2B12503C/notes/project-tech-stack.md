# project-tech-stack

## Arquitetura verificada
- Monorepo privado Turborepo 2.6 com pnpm 10 workspaces; Node mínimo 18 e CI em Node 20.
- Apps: web (portal público), backoffice (produto autenticado) e landing-page (marketing).
- Shared packages: address, analytics, auth, eslint-config, infra, masker, quality, tailwind-config, types, typescript-config, ui, utils e validations.
- Estrutura predominante por app: src/app, src/core, src/modules e integrações em core/infra ou infra.

## Stack por aplicação
- Todos usam Next.js 15.5.9 com App Router, Turbopack e React 19; o backoffice está em React 19.2.3, web e landing em React 19.0.x.
- TypeScript estrito; root fixa 5.8.2, enquanto alguns apps declaram versões compatíveis próprias.
- UI compartilhada em @imowiz/ui com Tailwind e configuração shadcn. Ícones via lucide-react.
- web: nuqs, React Hook Form, Zod, ky e @imowiz/analytics.
- backoffice: NextAuth/JWT, TanStack Query e Table, dnd-kit, TipTap, PostHog, nuqs e Playwright.
- landing-page: Next.js com OpenNext/Cloudflare e sem autenticação.
- backoffice e landing-page possuem build/deploy OpenNext para Cloudflare.

## HTTP, autenticação e tenant
- @imowiz/infra expõe HttpApiClient singleton baseado em ky, timeout de 30 s, hooks de auth e tenant e cache do tenant.
- O header canônico é X-TenantId. O web resolve slug por hostname e tenant ID via callback; callers não devem injetar o header manualmente.
- @imowiz/auth cria NextAuth com Credentials Provider, estratégia JWT e login padrão em /login.
- web valida NEXT_PUBLIC_API_BASE_URL e NEXT_PUBLIC_PORTAL_SUFFIX com @t3-oss/env-nextjs + Zod.
- backoffice valida AUTH_SECRET, AUTH_TRUST_HOST, COOKIE_DOMAIN, API pública e configuração PostHog.

## Contrato API
- Fonte de verdade: https://api-dev.imowiz.com.br/swagger/v1/swagger.json

## Tasks e qualidade
- Root: pnpm dev, build, test, check-types, lint, format e validate via Turbo.
- validate depende de build, check-types, lint e format.
- Há Vitest em packages/utils e Playwright e2e no backoffice; não assumir ausência total de testes.
- O package @imowiz/quality implementa quality gate e PR babysitter usados pelo GitHub Actions.
- Scripts locais de harness: pnpm harness:backoffice, pnpm harness:check e pnpm harness:e2e.