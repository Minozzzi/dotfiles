# qa-checklist

## Princípios
- Testar o contrato observável alterado e reproduzir o fluxo real; inspeção textual não substitui execução.
- Não alterar código, fixtures, snapshots ou testes apenas para mascarar uma falha.
- Contratos HTTP devem ser conferidos no Swagger DEV antes de mudanças em query params, DTOs ou mappers.
- Não expor CPF, senha, JWT, cookies, tenant IDs ou outros segredos nas evidências.

## Escolha da verificação
- Bug fix: reproduzir antes, aplicar correção e repetir o mesmo cenário.
- UI: executar o app, navegar no browser/Portal e observar layout, interação, console e rede.
- Contrato permanente: usar teste existente que cubra o comportamento; adicionar teste apenas quando surgir contrato observável novo.
- packages/utils possui Vitest; backoffice possui Playwright e2e. Rodar somente a suíte pertinente antes do gate amplo.

## Verificação técnica
1. Rodar o comando focado do pacote ou app alterado.
2. Para web, gerar tipos do Next antes da checagem quando necessário: pnpm build --filter=web na raiz ou pnpm build dentro de apps/web.
3. Rodar pnpm check-types. Se Turbo sofrer corrida com .next/types, confirmar em passos separados no app afetado; não classificar replay de cache como falha de código sem evidência.
4. Rodar pnpm lint e pnpm format no escopo pertinente.
5. Para entrega ampla, pnpm validate executa build, check-types, lint e format via Turbo.
6. Registrar comandos, resultados e warnings relevantes.

## Portal público web
- pnpm dev sobe três apps e as portas são dinâmicas; identificar o processo cujo cwd é apps/web em vez de assumir 3000.
- O host local do tenant deve usar o sufixo de apps/web/.env.example: imowiz.imowiz.com.br. Exemplo: http://imowiz.imowiz.com.br:<porta>.
- localhost não fornece slug de tenant e não valida o fluxo multitenant real.
- Validar rota /properties, detalhe /properties/<id>, paginação, limpar filtros, purpose sem seleção e filtros numéricos com null.
- Na rede, conferir query params PascalCase, search lowercase, Purpose Sale ou Rent e header X-TenantId.
- Não aprovar filtros de faixa Min* enquanto o Swagger não expuser esses parâmetros e o backend não demonstrar o comportamento.

## Backoffice e harness
- E2E local: pnpm harness:e2e; o host do harness é http://imowiz.imowiz.com:3000 conforme a regra operacional do projeto.
- Para flags do Playwright no wrapper, usar pnpm exec playwright test; evitar pnpm e2e -- quando o separador puder ser repassado como argumento literal.
- Se o fluxo parar em backend harness seed, registrar bloqueio backend, não falha do smoke frontend.

## Relatório
- Status: APROVADO, REPROVADO ou BLOQUEADO.
- Cenários e comandos executados.
- Evidências observadas, incluindo console e rede quando aplicável.
- Passos de reprodução e impacto de cada defeito.
- Bloqueios externos claramente separados de falhas do frontend.