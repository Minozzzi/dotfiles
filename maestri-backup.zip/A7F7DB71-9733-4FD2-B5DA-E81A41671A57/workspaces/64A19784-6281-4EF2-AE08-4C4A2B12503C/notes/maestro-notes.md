# Workspace notes index

> Entrada principal do workspace Imowiz. current-feature é a única note da entrega em andamento; as demais notes registram contexto permanente, operacional ou restrito.

## Contexto ativo
| Item | Valor |
|---|---|
| Workspace | imowiz-frontend |
| Workdir | /Users/guilhermeminozzi/projects/imowiz-frontend |
| Monorepo | 3 apps + 13 packages publicadas no pnpm workspace |
| Branch verificada | feat/portal-publico |
| Feature atual | current-feature |
| Backlog | backlog |
| Governança | maestri-governance |

## Fluxo essencial do time
Task Creator → Spec → Planner → Coder → Tester → Release Manager

Apoios: Spec ↔ Journey → Tester, Spec ↔ Architect → Planner e Coder HotFixer → Tester. O Maestro integra contexto, exceções e handoffs.

## Fontes de verdade do projeto
- package.json, pnpm-workspace.yaml e turbo.json: workspace, versões e task graph.
- apps/*/package.json: comandos e dependências por aplicação.
- packages/infra/src/http-api-client.ts e packages/auth/src/setup.ts: contratos compartilhados de HTTP e autenticação.
- Swagger DEV: https://api-dev.imowiz.com.br/swagger/v1/swagger.json.
- Instruções versionadas do repositório e código atual prevalecem sobre memórias e notes antigas.

## Contexto permanente
| Note | Conectada a | Finalidade |
|---|---|---|
| backlog | Encadeada a este índice | Ideias futuras priorizadas (Próximas, Ideias, Icebox) |
| project-tech-stack | Architect, Planner, Coder, HotFixer e Tester | Arquitetura, stack, contratos e comandos |
| qa-checklist | Journey, Coder, HotFixer e Tester | Verificação técnica, funcional, visual e de API |
| portal-config | Journey e Tester | Runtime local, browser e Portal |
| release-flow-rules | Release Manager | GitHub, commits, PRs, hooks e CI |
| maestri-governance | Encadeada a este índice | Regras do workspace |

## Contexto restrito
- restricted-login-credential permanece conectada somente ao Maestro. Compartilhar apenas durante autenticação real necessária.

## Lifecycle da feature
1. Registrar ideias futuras na note `backlog`, organizadas por prioridade (Próximas → Ideias → Icebox).
2. Ao iniciar uma feature, mover o item do `backlog` para `current-feature` com escopo expandido e marcar `[x]` no backlog.
3. Não criar notes individuais por feature.
4. Atualizar `current-feature` a cada mudança de objetivo, escopo, decisão, bloqueio, handoff, branch, PR ou evidência.
5. Após concluir e reportar, deixar a note contendo somente `# Feature atual`.
6. Ao trocar de prioridade antes da conclusão, confirmar com o usuário antes de substituir o conteúdo.