# Maestri governance

## Princípios
- Roles globais descrevem responsabilidades reutilizáveis; contexto de projeto e workdir pertence às notes do workspace.
- Instruções do usuário, do repositório e das notes pertinentes prevalecem sobre defaults de role.
- Use nomes estáveis, conteúdo escaneável e uma fonte de verdade para cada tipo de contexto.

## Roles e artefatos
- Cada agente recebe sua role global correspondente via `maestri role assign`.
- `.maestri/roles/<id>` é artefato gerado e deve permanecer fora do versionamento.
- Atualize roles somente pela CLI do Maestri.

## Lifecycle da feature
- Registre ideias futuras na note `backlog`, organizadas por prioridade (Próximas → Ideias → Icebox).
- Ao iniciar uma feature, mova o item do `backlog` para `current-feature` com escopo expandido e marque `[x]` no backlog.
- `current-feature` é a única note da feature em execução. Não crie nem preserve notes individuais por feature.
- Atualize `current-feature` após mudanças de objetivo, escopo, status, decisão, bloqueio, handoff, branch/PR ou evidência.
- Após concluir e reportar a feature, reescreva-a para conter exatamente `# Feature atual`.
- Ao trocar de prioridade antes da conclusão, confirme com o usuário antes de substituir o conteúdo.

## Topologia mínima
- Todos os agentes acessam `maestro-notes`; por essa cadeia também acessam `current-feature` e esta governança.
- Notes técnicas, de QA, portal e release conectam-se somente às roles que as utilizam diretamente.
- A credencial restrita permanece somente com o Maestro.
- Pares de agentes conectam-se apenas para handoffs explícitos; o Maestro integra exceções e não exige malha completa.

## Manutenção
- Notes vazias, duplicadas ou sem propósito podem ser removidas após autorização explícita.
- Notes sensíveis seguem menor privilégio e ficam fora da cadeia compartilhada.
- Revise a topologia quando roles ou fluxo do time mudarem.