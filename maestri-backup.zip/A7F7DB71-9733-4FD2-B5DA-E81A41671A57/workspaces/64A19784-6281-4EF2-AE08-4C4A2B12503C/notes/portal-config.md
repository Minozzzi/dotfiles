# portal-config

## Política
- Criar Portal somente quando a tarefa exige validação real de interface.
- pnpm dev inicia web, backoffice e landing-page em paralelo; a ordem das portas não é estável.
- Dar nome descritivo ao Portal e conectá-lo apenas aos agentes que executarão a validação.
- Nunca capturar credenciais, cookies, JWTs ou identificadores sensíveis.

## Portal público web
1. Iniciar pnpm dev.
2. Identificar qual processo Next pertence a apps/web pela porta de escuta e cwd do PID; não assumir localhost:3000.
3. Usar o tenant do exemplo versionado: http://imowiz.imowiz.com.br:<porta>. O middleware extrai o slug do hostname e persiste COOKIE_SUBDOMAIN.
4. Validar /properties, detalhe, filtros, paginação, console e requests conforme qa-checklist.
5. Confirmar X-TenantId no request ao backend sem expor seu valor em evidências públicas.

## Backoffice harness
- O runtime local padronizado do harness usa http://imowiz.imowiz.com:3000.
- Usar pnpm harness:backoffice para runtime e pnpm harness:e2e para o fluxo Playwright local quando o escopo for backoffice.
- A CI não pode depender desse host local, de backend local ou de estado da máquina.

## Encerramento
- Capturar somente evidências necessárias.
- Fechar o Portal ao concluir para liberar recursos.
- Consultar maestri portal --help antes de usar comandos ou flags ainda não verificados na sessão.