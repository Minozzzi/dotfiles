# release-flow-rules

## Repositório e branches
- Repositório GitHub: imowiz-frontend. O remote local ainda usa git@github.com:imowiz/frontend.git e redireciona para o nome atual.
- Branch principal verificada: main. O quality gate também escuta PRs para develop, embora develop não esteja presente no remote listado nesta revisão.
- Usar branch em inglês com prefixo convencional feat/, fix/ ou chore/ e escopo coerente. A branch ativa é feat/portal-publico.
- Não transportar artefatos locais, .env, credenciais, .next, tsbuildinfo, logs ou diretórios de ferramentas para commits.

## Commits e hooks
- commit-msg executa commitlint; usar Conventional Commits.
- pre-commit executa lint-staged.
- pre-push executa pnpm turbo run validate, que depende de build, check-types, lint e format.
- Em terminal headless, usar git commit --no-gpg-sign quando a configuração global de GPG impedir pinentry.
- git push --no-verify é exceção consciente, não default: somente após verificar os mesmos contratos por comandos direcionados e registrar o motivo.
- Antes do commit, revisar por console.log acidental; warnings podem não bloquear o hook.

## Pull Requests e CI
- Antes de abrir PR, obter reviewer do usuário; não reutilizar reviewer antigo por suposição.
- Usar base main salvo instrução explícita ou fluxo documentado diferente.
- Preservar template e registrar objetivo, mudanças, evidências, riscos e pendências backend.
- GitHub Actions executa matriz de lint, type-check, test, jscpd e audit; @imowiz/quality aplica o gate final.
- PR Babysitter roda em opened, synchronize e reopened.
- Após criar ou atualizar o PR, verificar source, target, reviewer, checks e URL. Atualizar current-feature com fatos confirmados.

## Repositório no MCP
- Para ferramentas GitHub que não seguem o redirect do remote antigo, usar owner imowiz e repo imowiz-frontend.
- Se autenticação ou permissão impedir leitura ou criação, informar a limitação; não afirmar que o PR foi consultado ou publicado.

## Atualização da tarefa
Publicar somente links confirmados:

#### PR
<link_confirmado>

Se a ferramenta não permitir comentar na tarefa, entregar o texto exato ao solicitante.