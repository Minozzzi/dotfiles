# Input Note
- Fake test, faça uma feature minina para eu validar se está funcional, não tem task no clickup