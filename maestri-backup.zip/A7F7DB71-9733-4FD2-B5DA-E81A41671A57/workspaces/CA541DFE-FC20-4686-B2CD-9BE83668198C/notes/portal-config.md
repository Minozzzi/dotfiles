# portal-config

## Política
- Trata-se de uma API de mocks configurada visualmente através da ferramenta Mockoon.
- O "Portal" para esta API refere-se ao **Mockoon Desktop Client**, onde todas as modificações devem ser feitas.

## Fluxo
1. Faça o download e instale o client do Mockoon para desktop (link disponível no README).
2. Abra o arquivo `data.json` deste repositório através do client de desktop.
3. Adicione ou edite os endpoints (path, método, body, status HTTP) diretamente na interface.
4. Salve as alterações; o arquivo `data.json` será atualizado.
5. Em caso de validação ou verificação de como os dados estão sendo entregues, utilize o preview ou inicie o server localmente na própria interface do Mockoon.