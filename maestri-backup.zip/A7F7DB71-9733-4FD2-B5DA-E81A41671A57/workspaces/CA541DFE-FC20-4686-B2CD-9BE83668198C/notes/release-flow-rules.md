# release-flow-rules

## Branches
- Crie a branch a partir da branch `dev`.
- Use o prefixo adequado ao tipo de alteração (`feat`, `fix` ou `chore`).
- Siga o padrão: `<tipo>/<id-da-task>_<até-três-palavras-em-inglês>`.
- Realize o commit apenas do arquivo `data.json` atualizado pelo Mockoon.

## Merge Requests
- Antes de criar MRs, obtenha do usuário o reviewer; não invente nem reutilize um reviewer antigo.
- Target branch: **Sempre `dev`**. Neste projeto, temos apenas o ambiente de desenvolvimento.
- Leia o template do repositório e preserve a formatação Markdown.
- Prefira GitLab MCP/API para metadados de MR.
- Verifique source branch, target branch, estado, reviewer e labels depois da criação.
- As alterações entram em vigor após o deploy via pipeline do GitLab CI.

## Atualização da tarefa
Publique somente o link confirmado do MR, no formato:

#### MR (dev)
<link_mr>

Se a ferramenta disponível não permitir comentar na tarefa, informe a limitação e entregue o texto exato ao solicitante; não afirme que publicou.