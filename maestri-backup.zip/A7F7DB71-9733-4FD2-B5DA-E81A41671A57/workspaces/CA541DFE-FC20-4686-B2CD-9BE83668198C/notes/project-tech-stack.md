# project-tech-stack

## Stack verificada
- Mockoon para mock de APIs (arquivo data.json).
- Dockerfile para build do contêiner do mock.
- GitLab CI para deploy automatizado.

## Estrutura relevante
- `data.json`: Arquivo de configuração exportado pelo Mockoon, contendo as rotas e respostas (ex: rotas do mock).
- `Dockerfile`: Imagem para empacotar/rodar o Mockoon.
- `.gitlab-ci.yml`: Pipeline de deploy do mock via CI/CD.
- `README.md`: Instruções para instalação do Mockoon e fluxo de commit.

## Verificação pré-entrega
- Configuração: Validar no Mockoon Client se as novas rotas/endpoints refletem o comportamento desejado.
- Formato: Garantir que o `data.json` continue como um JSON válido após salvamento no client de desktop.
- Nunca adicione credenciais reais aos mocks.