# qa-checklist

## Princípios
- Teste o contrato observável alterado: as rotas configuradas no Mockoon devem refletir fielmente as dependências ou casos de uso mockados.
- O `mock-api` serve para prover respostas estáticas ou dinâmicas simples para auxiliar o desenvolvimento; não complique além do necessário.
- Não exponha credenciais reais, documentos sensíveis ou tokens nas evidências nem no `data.json`.

## Verificação técnica
- Abra o `data.json` via client de desktop do Mockoon para garantir que os endpoints adicionados estão configurados corretamente (verbos HTTP, path, headers, e status code).
- Certifique-se de que o arquivo modificado é um JSON válido e sem conflitos.

## Verificação funcional
- Através da interface do Mockoon, ou executando-o localmente caso queira, valide se as rotas respondem os payloads de resposta simulados conforme a spec.

## Relatório
- Status: APROVADO ou REPROVADO.
- Endpoints (rotas e verbos) configurados ou modificados.
- Evidências observadas (status HTTP e/ou estrutura do payload em mock).
- (Se reprovado) Motivo e impacto.