# project-tech-stack

## Stack verificada
- AWS Lambda Function (API Gateway proxy) em Node.js 24 e TypeScript.
- Vitest para testes unitários e coverage.
- esbuild para empacotamento (CJS output).
- Middy para middleware (validação de request via `requestValidationMiddleware`).
- Zod para schemas de validação (`request-schema.ts`, `response-schema.ts`).
- Pacotes internos Aarin: `@aarintech/aarin-result-lib` (Result Pattern), `@aarintech/aarin-logging-lib`, `@aarintech/aarin-cache-lib`, `@aarintech/aarin-schema-validation-lib`, `@aarintech/consorcio-bra-client-lib` (integração Bradesco), `@aarintech/consorcio-utils-lib` (tokens, erros).
- npm é o gerenciador do projeto.

## Estrutura relevante
- `src/app.ts`: Entrypoint Lambda — recebe `APIGatewayProxyEvent`, extrai `salesId` do header, chama `execute()` e retorna `APIGatewayProxyResult`.
- `src/services/list-proposal-cancellation-reasons.service.ts`: Busca token do vendedor (`getSalesToken`), consulta API Bradesco (`/consorcio/consulta-dominio/v1/cancelamento`) e mapeia resposta.
- `src/mappers/to-app-response.mapper.ts`: Mapper da resposta de integração para DTO da aplicação.
- `src/dtos/`: DTOs de request/response e integração Bradesco.
- `src/constants/`: Constantes de códigos de erro.
- `src/request-schema.ts` / `src/response-schema.ts`: Schemas Zod para validação e documentação OpenAPI.
- `src/swagger.ts`: Geração de spec OpenAPI (zod-to-openapi).
- `__tests__/services/`: Testes unitários do service principal.
- `__tests__/stubs/`: Stubs de resposta de integração.
- Uso de Layers: imports como `/opt/name-layer` com `@ts-ignore` (runtime nodejs24).

## Verificação pré-entrega
- Testes: `npm run test` (validação local).
- Lint e Formatação: `npm run check` (ESLint + Prettier).
- Autofix: `npm run autofix`.
- Build: `npm run build`.