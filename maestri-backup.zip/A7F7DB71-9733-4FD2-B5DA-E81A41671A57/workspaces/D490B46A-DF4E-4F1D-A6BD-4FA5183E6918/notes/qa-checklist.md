# qa-checklist

## Princípios
- Teste o contrato observável alterado e reproduza o comportamento real; não valide por inspeção textual nem por suposição.
- Nunca altere código-fonte, fixtures ou testes apenas para fazer a verificação passar.
- Não exponha credenciais, documentos ou tokens nas evidências.
- Este projeto é uma Lambda com proxy API Gateway (request/response síncrono). Foco no contrato HTTP: headers, status codes, payload JSON e integração Bradesco.

## Verificação técnica
- Execute `npm run test` e assegure que todos os testes (incluindo os novos) passam.
- Execute `npm run check` para garantir aderência ao Lint e Prettier.
- Para CI/CD local, pode rodar `npm run test:ci` para checar o coverage se necessário.
- Valide se o build ocorre com sucesso: `npm run build`.
- Registre comando, resultado e falhas reais sem ocultar warnings relevantes.

## Verificação funcional da Lambda
- Valide o processamento do `APIGatewayProxyEvent` com header `salesId`.
- Teste respostas de sucesso (lista de motivos de cancelamento) e erro (Result Pattern: `InvalidSalesIdError`, `SalesTokenNotFoundError`, `InternalServerError`).
- Valide a integração mockada com Bradesco (`sendBradescoRequestWithRetry`) e o mapper `toAppResponse`.
- As evidências são logs do Vitest, payloads JSON de resposta e status codes HTTP.

## Relatório
- Status: APROVADO ou REPROVADO.
- Cenários de testes e comandos executados.
- Evidências observadas (JSON de payload, logs do Vitest).
- Passos de reprodução e impacto para cada defeito.