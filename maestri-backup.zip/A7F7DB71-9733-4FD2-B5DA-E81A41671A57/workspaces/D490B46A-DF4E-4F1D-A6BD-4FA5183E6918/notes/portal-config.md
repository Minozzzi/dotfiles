# portal-config

## Política
- Este projeto é uma Lambda com proxy API Gateway — expõe um endpoint HTTP síncrono (GET) para listar motivos de cancelamento de propostas.
- A documentação OpenAPI é gerada via `npm run build:swagger` e publicada no ReadMe.io pelo CI.

## Fluxo de verificação
1. Para validação local, rode os testes unitários: `npm run test`.
2. Para inspecionar o contrato da API, gere a spec: `npm run build && npm run build:swagger` e consulte `function/open-api-spec.json`.
3. O endpoint consome o header `salesId`, busca o token do vendedor e chama a API Bradesco `/consorcio/consulta-dominio/v1/cancelamento`.
4. Capture logs e payloads de resposta como evidências de sucesso/erro.