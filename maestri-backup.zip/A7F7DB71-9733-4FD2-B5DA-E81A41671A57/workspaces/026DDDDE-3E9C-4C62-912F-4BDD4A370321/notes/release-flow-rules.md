# release-flow-rules

## Branches por ambiente
- A branch DEVE ser criada/puxada SEMPRE a partir da branch `main`.
- Padrão de nomenclatura: `<tipo>/<id-da-task>_<até-três-palavras-em-inglês>`.
- Não inclua artefatos locais, credenciais ou diretórios de ferramentas no commit.

## Merge Requests
- Antes de criar MRs, obtenha do usuário o reviewer; não invente nem reutilize um reviewer antigo.
- Leia o template do repositório e preserve a formatação Markdown com linhas em branco antes dos cabeçalhos.
- Será aberto **apenas 1 MR**, apontando exclusivamente para DEV.
- Target: DEV → `dev` (ou a branch de desenvolvimento padrão).
- Use a label DEV.
- Prefira GitLab MCP/API para metadados de MR; não crie commits vazios nem use push options para editar título/descrição.
- Verifique source branch, target branch, estado, reviewer e labels depois da criação.

## Atualização da tarefa
Publique somente os links confirmados, no formato:

#### DEV
<link_mr_dev>

Se a ferramenta disponível não permitir comentar na tarefa, informe a limitação e entregue o texto exato ao solicitante; não afirme que publicou.
