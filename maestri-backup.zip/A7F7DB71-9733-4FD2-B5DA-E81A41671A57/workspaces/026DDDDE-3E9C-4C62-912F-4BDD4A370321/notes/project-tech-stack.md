# project-tech-stack

## Stack verificada
- .NET (C#) projetado com arquitetura limpa / DDD.
- DynamoDB como banco de dados NoSQL (via `docker-compose.yml`).
- API Web (Controllers, Swagger).
- Testes unitários na pasta `tests/`.

## Estrutura relevante
- `src/ConsorcioProductsDomain.Api/`: Camada de apresentação, Controllers, Middlewares, Program.cs.
- `src/ConsorcioProductsDomain.App/`: Serviços de aplicação, orquestração de casos de uso.
- `src/ConsorcioProductsDomain.Contracts/`: Contratos de dados (DTOs, Interfaces, Requests/Responses).
- `src/ConsorcioProductsDomain.CrossCutting/`: Injeção de dependência, configurações globais.
- `src/ConsorcioProductsDomain.Domain/`: Entidades de domínio, interfaces de repositórios, lógica de negócios pura.
- `src/ConsorcioProductsDomain.Domain.Events/`: Eventos de domínio.
- `src/ConsorcioProductsDomain.Infra/`: Repositórios, acesso ao DynamoDB, integrações externas.
- `tests/`: Projetos de testes da aplicação.
- `schemas/`: Scripts de inicialização e schemas do DynamoDB (`init-dynamodb-schemas.sh`).
- `deploy/`: Scripts de infraestrutura (TypeScript).

## API e DDD
- Siga os princípios do Domain-Driven Design: Entidades, Objetos de Valor, Agregados, e Repositórios.
- Option Monad e Result Pattern devem ser usados para controle de fluxo e erros, evitando exceptions para fluxo de negócio.
- Single Responsibility para Services.
- Siga as configurações e padrões já existentes no repositório; não introduza uma segunda convenção.

## Verificação pré-entrega
- Compilação: `dotnet build`.
- Testes: `dotnet test`.
- Formatação: `dotnet format` se aplicável.
- Funcional: Testar endpoints localmente (DynamoDB no docker + dotnet run/run via API).