# Restricted: login credentials

> Conteúdo sensível deste workspace. Manter conectada somente ao Maestro. Não copiar para código, logs, screenshots, MRs, tasks ou notes compartilhadas.

## Credencial de teste registrada
| Campo | Valor |
|---|---|
| Client ID / Usuário | A definir |
| Client Secret / Senha | A definir |

## Uso
Compartilhar apenas com o agente que executar autenticação real e somente durante a validação necessária. Recolher o acesso ao concluir.