# qa-checklist

## Princípios
- Teste o contrato observável alterado da API e reproduza o comportamento real; não valide por inspeção textual nem por suposição.
- Nunca altere código-fonte, mocks ou testes apenas para fazer a verificação passar.
- Não exponha credenciais, documentos ou tokens nas evidências.

## Verificação técnica
- Execute testes unitários focados que cobrem a alteração de domínio/serviço.
- Verifique a compilação de todo o projeto: `dotnet build`.
- Para mudanças permanentes, execute a suíte completa: `dotnet test`.
- Analise a formatação e lint: `dotnet format` ou ferramentas estáticas pertinentes, sem usar auto-fix se não intencional.
- Registre comando, resultado e falhas reais sem ocultar warnings relevantes.

## Verificação funcional da API
- Inicie a API e as dependências (ex: DynamoDB via Docker).
- Valide os endpoints alterados via Swagger ou curl.
- Valide cenários de sucesso (200/201), bad request (400), erros de validação (422), não autorizado (401/403) e erro interno (500) pertinentes ao escopo.
- Inspecione logs da API e payloads de request/response; confira persistência no banco (DynamoDB).
- Capturas de logs e payloads são evidências para alterações na API.

## Relatório
- Status: APROVADO ou REPROVADO.
- Cenários e comandos executados.
- Evidências observadas.
- Passos de reprodução e impacto para cada defeito.