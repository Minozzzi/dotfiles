# qa-checklist

## Princípios
- Teste o conteúdo alterado: a documentação deve ser precisa, completa e fiel à implementação real das APIs e fluxos.
- Não exponha credenciais reais, tokens ou dados sensíveis nos documentos.
- Markdown deve seguir os templates do projeto (`templates/`).

## Verificação técnica
- Build limpo: `mkdocs build --strict` deve completar sem erros ou warnings.
- Links internos: todos os links entre páginas e âncoras devem resolver corretamente.
- Nav (`mkdocs.yml`): arquivos adicionados/removidos devem estar refletidos na seção `nav`.
- Diagramas Mermaid: renderizam corretamente no tema Material.
- Specs Swagger/OpenAPI: tag `swagger-ui` válida e renderizando.

## Verificação de conteúdo
- TDDs: objetivo, fluxo, payloads (request/response), status HTTP, regras e edge cases documentados.
- ADRs: contexto, decisão, consequências e status.
- ERDs: entidades, atributos e relacionamentos coerentes com a implementação.
- Consistência: terminologia e nomenclatura uniforme entre documentos relacionados.

## Verificação EventCatalog (se alterado)
- `cd events-catalog && npm run build` deve completar sem erros.
- Eventos e serviços descritos fielmente.

## Relatório
- Status: APROVADO ou REPROVADO.
- Páginas adicionadas, modificadas ou removidas.
- Evidências: resultado do build, screenshots de renderização (se relevante).
- (Se reprovado) Motivo e impacto.