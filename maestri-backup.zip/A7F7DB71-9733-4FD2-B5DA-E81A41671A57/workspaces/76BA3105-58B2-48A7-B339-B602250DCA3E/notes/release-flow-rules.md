# release-flow-rules

## Branches
- Branch principal e única: **`main`**. Não existe `dev`, `staging` ou equivalente neste projeto.
- Crie a branch de trabalho a partir de `main`.
- Use o prefixo adequado ao tipo de alteração (`feat`, `fix` ou `chore`).
- Siga o padrão: `<tipo>/<id-da-task>_<até-três-palavras-em-inglês>`.

## Merge Requests
- Antes de criar MRs, obtenha do usuário o reviewer; não invente nem reutilize um reviewer antigo.
- Target branch: **sempre `main`**.
- Leia o template do repositório e preserve a formatação Markdown.
- Prefira GitLab MCP/API para metadados de MR.
- Verifique source branch, target branch, estado, reviewer e labels depois da criação.
- As alterações entram em vigor após o deploy via pipeline do GitLab Pages (job `pages` na `main`).

## Atualização da tarefa
Publique somente o link confirmado do MR, no formato:

#### MR (main)
<link_mr>

Se a ferramenta disponível não permitir comentar na tarefa, informe a limitação e entregue o texto exato ao solicitante; não afirme que publicou.