# project-tech-stack

## Stack verificada
- **MkDocs** (v1.6.1) com tema **Material** (v9.6.14) para documentação técnica.
- **EventCatalog** (v2) para catálogo de eventos (EventBridge, AsyncAPI, OpenAPI).
- **Python 3.11** (CI) / **3.9** (Docker) para build da documentação.
- **Node.js 18** para build do EventCatalog no CI.
- **GitLab CI** para deploy automatizado (GitLab Pages).
- **Docker / Docker Compose** para ambiente local.

## Plugins MkDocs
- `swagger-ui-tag` — renderiza specs Swagger/OpenAPI inline.
- `glightbox` — lightbox para imagens.
- `panzoom` — zoom interativo em diagramas.
- `pymdownx.superfences` — fences para Mermaid e code blocks.

## Estrutura relevante
```
consorcio-docs/
├── docs/                    # Conteúdo Markdown (TDDs, ADRs, ERDs)
│   ├── general/             # Visão macro, extensões
│   ├── sales/               # WL de Vendas (Auth, Products, Register...)
│   ├── backoffice/          # Backoffice (Rules, CMS, Reports...)
│   ├── wholesale/           # WL Atacado
│   ├── self-contemplation/  # Auto Contemplação
│   ├── insurance/           # Seguros
│   ├── frontend/            # Frontend
│   ├── events/              # Eventos
│   └── assets/              # Imagens e recursos
├── events-catalog/          # EventCatalog (Node.js app separada)
├── templates/               # Templates de documentação (ADR, TDD, DynamoDB)
├── overrides/               # Custom MkDocs theme overrides
├── mkdocs.yml               # Configuração principal MkDocs + nav
├── requirements.txt         # Dependências Python
├── Dockerfile               # Imagem para dev local
├── docker-compose.yml       # Compose para dev local
└── .gitlab-ci.yml           # Pipeline CI/CD
```

## Comandos essenciais
| Ação | Comando |
|---|---|
| Dev local (Docker) | `docker-compose up` |
| Dev local (Python) | `pip install -r requirements.txt && mkdocs serve` |
| Build docs | `mkdocs build --site-dir public` |
| Build EventCatalog | `cd events-catalog && npm ci && npm run build` |

## Verificação pré-entrega
- Build limpo: `mkdocs build --strict` sem warnings.
- Links internos resolvendo corretamente.
- Markdown válido e conforme templates do projeto.
- Diagramas Mermaid renderizando.
- Specs Swagger válidas (se alteradas).