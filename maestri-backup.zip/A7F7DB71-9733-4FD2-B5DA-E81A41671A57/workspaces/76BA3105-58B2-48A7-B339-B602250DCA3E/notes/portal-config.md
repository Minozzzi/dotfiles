# portal-config

## Ambiente local
Este projeto é uma documentação técnica servida via **MkDocs** com tema **Material**.

### MkDocs (documentação principal)
| Item | Valor |
|---|---|
| URL local | `http://localhost:8000` |
| Comando (Python) | `mkdocs serve` |
| Comando (Docker) | `docker-compose up` |
| Hot reload | Sim — alterações em `docs/` refletem automaticamente |

### EventCatalog (catálogo de eventos)
| Item | Valor |
|---|---|
| Diretório | `events-catalog/` |
| Comando dev | `cd events-catalog && npm run dev` |
| Build | `cd events-catalog && npm ci && npm run build` |

## Deploy
- Deploy automático via **GitLab Pages** na branch `main`.
- A pipeline CI (`pages` job) faz build do MkDocs + EventCatalog e publica em `public/`.
- EventCatalog fica acessível em `/events/` dentro do site.

## Navegação
- O site possui abas de navegação: Início, Geral, WL de Vendas, Backoffice, WL Atacado, Auto Contemplação, Seguros e Eventos.
- Cada seção organiza TDDs, ADRs, ERDs e TSDs por API/serviço.