# qa-checklist

## Princípios
- Toda alteração em código Terraform deve ser validada e formatada antes de comitar.
- Evite deixar secrets ou chaves hardcoded; eles serão pegos pelos pre-commit hooks (detect-aws-credentials, detect-private-key, checkov).
- O projeto usa validação rígida através do `antonbabenko/pre-commit-terraform`.

## Verificação técnica
1. **Formatação e Linting:**
   Na raiz do projeto ou no diretório `lambda`, execute os hooks:
   `pre-commit run --all-files`
   Isso executará automaticamente:
   - `terraform_fmt`
   - `terraform_tflint`
   - `terraform_validate`
   - `terraform_checkov`
2. **Validação Manual:**
   Se preferir testar uma camada apenas:
   - `cd lambda`
   - `terraform init -backend=false`
   - `terraform validate`
3. **Plano de execução (quando aplicável):**
   Se o ambiente possuir credenciais ou mocking, verificar se `terraform plan` conclui com sucesso, detalhando as mudanças na AWS.

## Relatório
- Status: APROVADO ou REPROVADO.
- Alteração solicitada (ex: adição de variável de ambiente, aumento de timeout).
- Resultado das execuções do `pre-commit`.
- Diff do `terraform plan` (opcional/se possível no ambiente local).