# project-tech-stack

## Stack verificada
- Terraform para Infraestrutura como Código (IaC).
- Módulo Lambda customizado Aarin (`gitlab.com/aarintechfin/terraform-module-lambda/aws`).
- Repositório focado exclusivamente na infraestrutura (sem código-fonte da aplicação; assume-se build/deploy via S3 ou CI/CD pipeline).
- GitLab CI/CD para execução de pipelines (descrito em `.gitlab-ci.yml`).
- `pre-commit` com hooks do `antonbabenko/pre-commit-terraform` para linting e validação.

## Estrutura relevante
- `lambda/`: Diretório principal contendo o código Terraform.
  - `lambda.tf`: Declaração do módulo da function.
  - `provider.tf`: Configuração de provedor da AWS.
  - `backend.tf`: Configuração do backend remoto de estado.
  - `locals.tf`: Variáveis e valores dinâmicos de acordo com o ambiente (workspace Terraform).
- `.pre-commit-config.yaml`: Configuração dos hooks de validação (fmt, tflint, checkov, validate).
- `.gitlab-ci.yml`: Definição de jobs de integração e delivery contínuos.

## Fluxo de Trabalho (Terraform)
- Sempre rodar validação e lint no diretório `lambda/`.
- As variáveis são lidadas por mapa através do local (ex: `local.runtime[local.environment_workspace]`).
- Qualquer alteração de infraestrutura deve ser validada usando os hooks do pre-commit.