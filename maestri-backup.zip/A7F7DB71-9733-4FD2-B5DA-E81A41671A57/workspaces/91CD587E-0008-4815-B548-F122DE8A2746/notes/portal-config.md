# portal-config

## Política
- Este é um projeto exclusivo de infraestrutura Terraform (`consorcio-get-totals-report-by-vendor-tf`). Não há aplicação local e, portanto, nenhum portal web, UI ou Swagger integrado.
- A função lambda real, a qual será provisionada por este repositório, terá sua documentação ou contratos gerenciados em outro lugar (ex: no repositório do código fonte).

## Fluxo
1. Para validar o comportamento da infraestrutura, a interface primária é o output do `terraform plan` e as validações estáticas do Checkov/TFLint.
2. Acessos a AWS via Portal/Console (caso necessários durante um troubleshooting real) não devem ter credenciais inseridas neste repositório.
3. Se um desenvolvedor solicitar verificar acessos ou variáveis, verifique o `locals.tf` onde as variáveis de ambiente e subnets para cada `environment_workspace` estão declaradas.