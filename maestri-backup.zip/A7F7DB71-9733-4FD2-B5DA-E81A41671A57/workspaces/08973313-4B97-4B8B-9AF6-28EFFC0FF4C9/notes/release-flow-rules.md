# release-flow-rules

## Branches por ambiente
- DEV: crie a branch a partir de `dev`, com tipo adequado (`feat`, `fix` ou `chore`) e padrão `<tipo>/dev_<id-da-task>_<até-três-palavras-em-inglês>`.
- SDX: crie uma branch limpa a partir de `sandbox` e aplique somente os commits aprovados em DEV por cherry-pick.
- PRD: crie uma branch limpa a partir de `main` e aplique somente os commits aprovados em DEV por cherry-pick.
- Nunca derive SDX ou PRD diretamente da feature branch de DEV.
- Não inclua artefatos locais, credenciais ou diretórios de ferramentas no commit.

## Merge Requests
- Antes de criar MRs, obtenha do usuário o reviewer; não invente nem reutilize um reviewer antigo.
- Leia o template do repositório e preserve a formatação Markdown com linhas em branco antes dos cabeçalhos.
- Targets: DEV → `dev`; SDX → `sandbox`; PRD → `main`.
- Use labels DEV/SDX/PRD. SDX e PRD devem ser Draft quando esse for o fluxo vigente.
- Registre as dependências: SDX depende de DEV; PRD depende de DEV e SDX.
- Prefira GitLab MCP/API para metadados de MR; não crie commits vazios nem use push options para editar título/descrição.
- Verifique source branch, target branch, estado, reviewer, labels e dependências depois da criação.

## Atualização da tarefa
Publique somente os links confirmados, no formato:

#### DEV
<link_mr_dev>

#### SDX
<link_mr_sdx>

#### PRD
<link_mr_prd>

Se a ferramenta disponível não permitir comentar na tarefa, informe a limitação e entregue o texto exato ao solicitante; não afirme que publicou.