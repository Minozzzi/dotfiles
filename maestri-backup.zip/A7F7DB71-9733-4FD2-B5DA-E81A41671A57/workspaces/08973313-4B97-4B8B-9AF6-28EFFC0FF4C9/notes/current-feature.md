# Feature Atual
Task: [F][BL][ID 306 - Boleto Balcão] - Integrar emissão de boleto (POST /v1/contracts/ticket)
ClickUp: 86ak98gzf
Branch: feat/dev_86ak98gzf_issue_ticket

## Objetivo
Criar a integração com o novo endpoint POST /v1/contracts/ticket e consumir os dados de boleto na tela First Payment Details. Este endpoint retorna o PDF do boleto em base64 e a linha digitável.

## Requisitos e Especificações técnicas
1. Endpoint RTK Query: Criar `issueTicket` no service de `contracts` já existente:
   - Utilizar `build.query` (mesmo sendo POST) para permitir concorrência automática via `useIssueTicketQuery`.
   - Método: POST
   - URL: `/v1/contracts/ticket`
   - Body: `{ documentId: number }`
   - Response: `{ ticketPdf: string, digitableLine: string }`
   - Adicionar os types em `types.ts`.
2. Estratégia de loading e chamadas em paralelo (em `use-first-payment-details.ts`):
   - Disparar `useGetContractsQuery` e `useIssueTicketQuery` (ambos usando o `proposalNumber`/`documentId` disponivel no hook).
   - Combinar o loading: `const isLoading = isQueryLoading || isFetching || isTicketLoading || isTicketFetching`.
3. Mapeamento de resposta:
   - Adicionar o `digitableLine` recebido da chamada de ticket ao `mappedData` final, assim como o `ticketPdf` (que pode ser retornado no root do hook para ser usado pelo botão de download).
4. Download do PDF:
   - Criar uma função `handleDownloadTicket` no hook que receba o `ticketPdf` em base64 e faça o download (exemplo: criar link `data:application/pdf;base64,... ` e `.click()`).
   - Retornar essa função e o `ticketPdf` para a tela `FirstPaymentDetailsPage` e associar ao clique do ícone de download existente na UI.
5. Tratamento de Erros:
   - Se `isTicketError` ocorrer, o comportamento ideal é jogar o erro para a Error Boundary? Como a task é de detalhes do boleto E contrato, se o boleto falhar, a tela inteira falha. Sim, usar `if (isError || isTicketError) throw new Error("Failed to fetch ticket data");`.
6. Testes:
   - Atualizar `use-first-payment-details.test.tsx` para mockar também a chamada do `useIssueTicketQuery` e a lógica de `handleDownloadTicket`.

## Status
## Plano de Implementação (Planner)

1. **Service Contracts (`src/config/data/services/contracts`):**
   - **`types.ts`**: Adicionar interface `IssueTicketRequest` (com `documentId: number`) e `IssueTicketResponse` (com `ticketPdf: string` e `digitableLine: string`).
   - **`index.ts`**: Adicionar o endpoint `issueTicket` utilizando `build.query<IssueTicketResponse, IssueTicketRequest>`. O método será `POST`, URL `/v1/contracts/ticket` e body com `documentId`. Exportar `useIssueTicketQuery`.

2. **Atualizar o hook `useFirstPaymentDetails` (`src/modules/first-payment/details/hooks/use-first-payment-details.ts`):**
   - Importar e disparar `useIssueTicketQuery({ documentId: Number(proposalNumber) }, { skip: !proposalNumber })`.
   - Combinar os loadings: `const isLoading = isContractLoading || isContractFetching || isTicketLoading || isTicketFetching;`.
   - Lançar exceção combinada: `if (isContractError || isTicketError) throw new Error("Failed to fetch ticket data");`.
   - Injetar a linha digitável (`ticketResponse?.digitableLine ?? ""`) no `mappedData` do `useMemo` para sobrescrever o mock antigo.
   - Criar função de download com `useCallback`:
     ```typescript
     const handleDownloadTicket = useCallback(() => {
       if (!ticketResponse?.ticketPdf) return;
       const link = document.createElement("a");
       link.href = `data:application/pdf;base64,${ticketResponse.ticketPdf}`;
       link.download = `boleto_${proposalNumber}.pdf`;
       document.body.appendChild(link);
       link.click();
       document.body.removeChild(link);
     }, [ticketResponse?.ticketPdf, proposalNumber]);
     ```
   - Exportar `handleDownloadTicket` junto com o objeto retornado do hook.

3. **Atualizar a UI (`src/modules/first-payment/details/index.tsx`):**
   - Extrair `handleDownloadTicket` da chamada do hook.
   - Substituir o `onClick={() => console.log("Baixar PDF boleto")}` por `onClick={handleDownloadTicket}` nos botões da versão Desktop e Mobile.

4. **Atualizar Testes (`use-first-payment-details.test.tsx`):**
   - Adicionar o mock para `useIssueTicketQuery` no arquivo de testes, em paralelo ao `useGetContractsQuery`.
   - Testar fluxo de erro se o ticket falhar (`isTicketError: true` disparando `throw new Error`).
   - (Opcional/Recomendado) Adicionar teste verificando o `handleDownloadTicket` usando `jest.spyOn(document, 'createElement')` para atestar que o href de base64 e `.click()` foram acionados.

Status: **Especificação técnica (Planner) finalizada. Coder pode iniciar a execução.**