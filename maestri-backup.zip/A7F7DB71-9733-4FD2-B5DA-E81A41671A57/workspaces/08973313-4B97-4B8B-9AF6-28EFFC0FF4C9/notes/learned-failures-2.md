# learned-failures

Central de aprendizados de falhas confirmadas no ambiente local e na aplicação.

## 🛠️ Erros de Ambiente e Infraestrutura Local
- **pnpm bloqueado no Windows:** Se o execution policy bloquear `pnpm.ps1`, use `pnpm.cmd` localmente ou o wrapper `node ./scripts/harness/run-powershell.mjs`.
- **Playwright sem Chromium:** Sempre instale o browser local antes do e2e rodando `pnpm --filter backoffice exec playwright install chromium`.
- **Porta 8080 em uso (API):** Verifique se a API local já está rodando antes de iniciar um novo processo (reutilize se `/health/ready` já responder).
- **Conflito de Container Postgres:** O Compose pode falhar se o container `imowiz-postgres-harness` já existir. Reutilize-o em vez de recriar.
- **Compose em Background (-d):** No PowerShell local, flags com hífen podem ser consumidas incorretamente por wrappers. Chame `docker compose up -d postgres` diretamente.

## 🧠 Armadilhas de Lógica de Negócio (Paywall & Checkout)
- **Cache do Next.js App Router:** Não use `router.replace` para redirecionar após o sucesso do pagamento (pode exibir o `PaywallOverlay` novamente devido ao cache da rota). Use `window.location.replace("/properties")` para forçar o recarregamento.
- **Polling de Pagamento:** Use array de dependências vazio `[]` no `useEffect` e controle os intervalos via refs para evitar race conditions.
- **Validação de Plano:** Cheque `planActive` diretamente no retorno do método `update()` antes de liberar a tela.