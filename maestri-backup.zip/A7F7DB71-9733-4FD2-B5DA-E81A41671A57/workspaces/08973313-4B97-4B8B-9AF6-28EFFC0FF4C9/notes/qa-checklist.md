# qa-checklist

## Princípios
- Teste o contrato observável alterado e reproduza o comportamento real; não valide por inspeção textual nem por suposição.
- Nunca altere código-fonte, fixtures, snapshots ou testes apenas para fazer a verificação passar.
- Não exponha credenciais, documentos ou tokens nas evidências.

## Verificação técnica
- Execute o teste focado que cobre o contrato alterado.
- Execute `pnpm type-check`.
- Para mudanças permanentes, execute `pnpm test` depois do teste focado.
- Execute `pnpm lint` quando o escopo exigir; não use auto-fix como substituto de análise.
- Registre comando, resultado e falhas reais sem ocultar warnings relevantes.

## Verificação funcional e visual
- Para mudanças de UI, inicie o servidor, use a URL real emitida por `pnpm dev` e percorra o fluxo no browser/Portal do Maestri.
- Valide estados normal, loading, vazio, erro, interação por teclado, responsividade e acessibilidade pertinentes ao escopo.
- Inspecione console e requests de rede; confira payloads, autenticação e headers de tenant sem registrar segredos.
- Capturas de tela são evidência para alterações visuais, não uma exigência para mudanças sem interface.

## Relatório
- Status: APROVADO ou REPROVADO.
- Cenários e comandos executados.
- Evidências observadas.
- Passos de reprodução e impacto para cada defeito.