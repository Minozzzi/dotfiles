# project-tech-stack

## Stack verificada
- Next.js 16.1 (App Router), React 19.2 e TypeScript 5.
- Tailwind CSS v4 com `@tailwindcss/postcss`.
- Framer Motion para animações e transições.
- Lenis para smooth scroll.
- React Three Fiber (`@react-three/fiber`) e Drei para seção 3D.
- Lucide React para ícones.
- npm é o gerenciador do projeto (lockfile: `package-lock.json`).

## Estrutura relevante
- `src/app/`: rotas, layout e globals.css (App Router).
- `src/components/`: todos os componentes da landing page (Hero, About, Services, Team, Gallery, Testimonials, Faq, Footer, etc.).
- `src/constants/`: constantes de animação centralizadas.
- `public/`: assets estáticos (logo SVG, favicon).
- Siga as configurações e padrões já existentes no repositório; não introduza uma segunda convenção.

## Qualidade de código
- ESLint 9 com `eslint-config-next`.
- Husky + lint-staged para pre-commit (ESLint auto-fix em `*.{ts,tsx}`).
- Commitlint com Conventional Commits.

## Verificação pré-entrega
- Build: `npm run build`.
- Lint: `npm run lint`.
- Dev server: `npm run dev`.
- Não há test runner configurado neste projeto.