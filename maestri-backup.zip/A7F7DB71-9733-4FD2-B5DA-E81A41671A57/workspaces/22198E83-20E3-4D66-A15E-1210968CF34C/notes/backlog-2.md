# Backlog

> Ideias futuras priorizadas. Mover para `current-feature` ao iniciar.

## 🔥 Próximas
- 

## 💡 Ideias

- 

## 🧊 Icebox
- 