# Feature atual

**Validar e corrigir toda a página de propriedades e listagem (/properties)**
**Objetivos:**
Resolver todos os pontos visuais e funcionais levantados na tela de listagem e detalhe de propriedade do portal web.

**Tarefas Atuais:**
- **Detalhe (1):** Corrigir estado de falha na criação de lead via WhatsApp (criar estado de erro com botão de ação para tentar novamente ou falar no wpp)
- **Detalhe (2):** Ajustar grid de imagens para quando houver apenas uma imagem na propriedade.
- **Lista (3):** Adicionar padding lateral no botão "Qualquer" dos filtros numéricos de quartos/banheiros/vagas.
- **Lista (4 e 5):** Ajustar badges nos cards de propriedades (Finalidade com `bg-primary`, e Tipo do imóvel harmonioso sem distorcer cores fortes).
- **Lista (6):** Melhorar UI do dropdown "Select" para usar versão mais suave da cor do tenant (bg-primary/10 text-primary) ao invés do accent cinza.
- **Lista (7):** Corrigir a cor cinza do texto nos botões "Comprar/Alugar" do filtro (toggle group style).