# portal-config

## Política
- O Portal é efêmero e deve ser criado somente quando a tarefa exige validação real de interface.
- Inicie o projeto com `npm run dev` e use a URL exata exibida pelo servidor; não assuma que `localhost:3000` é a URL canônica.
- Dê ao portal um nome descritivo e conecte-o apenas aos agentes que executarão a validação.

## Fluxo
1. Confirme que o servidor está pronto e que a URL responde.
2. Crie ou navegue o Portal para a URL emitida pelo servidor.
3. Valide o fluxo, console e rede conforme `qa-checklist`.
4. Capture evidências relevantes sem expor credenciais ou tokens.
5. Feche o Portal ao concluir para não manter recursos ociosos.

Consulte `maestri portal --help` antes de usar flags ou comandos que não tenham sido verificados nesta sessão.