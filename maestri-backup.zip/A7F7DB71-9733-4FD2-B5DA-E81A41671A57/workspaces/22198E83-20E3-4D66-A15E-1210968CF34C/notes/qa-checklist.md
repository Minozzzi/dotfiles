# qa-checklist

## Princípios
- Teste o contrato observável alterado e reproduza o comportamento real; não valide por inspeção textual nem por suposição.
- Nunca altere código-fonte, fixtures ou configuração apenas para fazer a verificação passar.
- Não exponha credenciais ou tokens nas evidências.

## Verificação técnica
- Execute `npm run build` para confirmar que a build compila sem erros.
- Execute `npm run lint` para validar regras de lint.
- Não há test runner neste projeto; valide pelo comportamento real no browser.

## Verificação funcional e visual
- Para mudanças de UI, inicie o servidor com `npm run dev` e use a URL real emitida pelo servidor.
- Valide animações, scroll suave (Lenis), responsividade (mobile/tablet/desktop), cursor customizado e interações 3D.
- Verifique estados de hover, transições Framer Motion, carrossel de depoimentos e FAQ accordion.
- Inspecione console para erros de runtime, warnings de React e problemas de hidratação.

## Relatório
- Status: APROVADO ou REPROVADO.
- Cenários e comandos executados.
- Evidências observadas.
- Passos de reprodução e impacto para cada defeito.