# release-flow-rules

## Branch principal
- Este projeto usa a branch `main` como branch principal e única.
- Não há branches de ambiente separadas (sem `dev`, `sandbox` ou `staging`).

## Branches de feature
- Crie a branch a partir de `main`, com tipo adequado (`feat`, `fix` ou `chore`) e um nome descritivo em inglês.
- Padrão: `<tipo>/<descrição-curta-em-inglês>` (ex: `feat/add-pricing-section`).
- Não inclua artefatos locais, credenciais ou diretórios de ferramentas no commit.

## Commits
- Siga Conventional Commits (`feat:`, `fix:`, `docs:`, `style:`, `refactor:`, `test:`, `chore:`).
- Commitlint valida a mensagem via Husky hook.
- Lint-staged executa ESLint nos arquivos staged antes do commit.

## Pull/Merge Requests
- Target: sempre `main`.
- Antes de criar MRs, obtenha do usuário o reviewer; não invente nem reutilize um reviewer antigo.

## Repositório
- Remote: `origin` → GitHub.
- Licença: privada, uso exclusivo URBZ Barber Block.