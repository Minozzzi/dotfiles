# Restricted: credenciais

> Nenhuma credencial registrada para este workspace.
> Se necessário, adicione aqui credenciais de teste. Manter conectada somente ao Maestro. Não copiar para código, logs, screenshots, MRs, tasks ou notes compartilhadas.